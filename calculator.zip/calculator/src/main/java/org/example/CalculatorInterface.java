package org.example;

public interface CalculatorInterface {

    void performAddition(double x, double y);
    void performSubtraction(double x, double y);
    void performMultiplication(double x, double y);
    void performDivision(double x, double y);
}
