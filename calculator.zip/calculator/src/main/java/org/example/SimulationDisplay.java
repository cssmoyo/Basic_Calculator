package org.example;

//Simulates the output, ensuring that the correct value is displayed.
public class SimulationDisplay {

    private String text;

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
